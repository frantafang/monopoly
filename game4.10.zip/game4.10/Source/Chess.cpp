#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include "audio.h"
#include "gamelib.h"
#include "CEraser.h"
#include "Chess.h"

namespace game_framework {
	/////////////////////////////////////////////////////////////////////////////
	// CBall: Ball class
	/////////////////////////////////////////////////////////////////////////////

	Chess::Chess()
	{
		x = 5;
		y = 880; 
		dx = dy = 12;
		index = speed = 0;
	}

	void Chess::LoadBitmap()
	{
		bmpChess.LoadBitmap(IDB_CHESS1, RGB(255, 255, 255));		// ���J�y���ϧ�
	}

	void Chess::OnShow()
	{
		bmpChess.SetTopLeft(x, y);
		bmpChess.ShowBitmap();
	}

	void Chess::OnMove()
	{
		//int chessArray[30];
		for (int i = 0; i < 9; i++)
		{
			//bmpChess.SetTopLeft(x, y - dy * i);
		}


			//
			// �p��y�V����ߪ��첾�qdx, dy
			//
			const int STEPS = 30;
			static const int DIFFX[] = { 35, 32, 26, 17, 6, -6, -17, -26, -32, -34, -32, -26, -17, -6, 6, 17, 26, 32, };
			static const int DIFFY[] = { 0, 11, 22, 30, 34, 34, 30, 22, 11, 0, -11, -22, -30, -34, -34, -30, -22, -11, };
			index++;
			if (index >= STEPS)
				index = 0;
			dx = DIFFX[index];
			dy = DIFFY[index];
		
	}
}